#ifndef LISTINDEX_H  //ifndef begin
#define LISTINDEX_H

#include "listbase.h"

class ListIndex : public Listbase
{
    public:
        ListIndex();
        void display(string message);
    private:

};






#endif // endif begin
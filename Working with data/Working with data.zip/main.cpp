#include <iostream>

#include "work.h"

using namespace std;

int main()
{
    App work;
    work.run();
    return 0;
}